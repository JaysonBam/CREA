<script setup>
import { Toast } from "primevue";
</script>

<template>
  <Toast />
  <router-view />
</template>

<style scoped></style>
